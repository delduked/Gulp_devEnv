///////////////////////////////////////////////////////////////
/// you must install these first in this order for gulp to work
\\\ Make sure NODE.JS IS INSTALLED
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


/// run these commands in the root of your project

npm init
npm install gulp gulp-sass gulp-jade gulp-pug browser-sync gulp-autoprefixer --save-dev
