var gulp = require('gulp');
var jade = require('gulp-jade');
var sass = require('gulp-sass');
var autoprefixer = require('gulp-autoprefixer');
var browserSync = require('browser-sync');

gulp.task('jade', function(){
   return gulp.src('site/*.jade')
      .pipe(jade()) /* COMPile jade into html files */
      .pipe(gulp.dest('site'))
      .pipe(browserSync.reload({
         stream: true
      }))
});

gulp.task('sass', function() {
   return gulp.src('site/css/*.sass')
      .pipe(sass()) //converts sass to css
      .pipe(gulp.dest('site/css'))
      .pipe(autoprefixer('last 2 version', 'safari 5', 'ie 8', 'ie 9', 'ff 17', 'opera 12.1', 'ios 6', 'android 4'))
      .pipe(browserSync.reload({
         stream: true
      }))
});

gulp.task('browserSync', function() {
  browserSync.init({
    server: {
      baseDir: 'site'
    },
  })
});

gulp.task('watch', ['jade','sass','browserSync'], function(){
   gulp.watch('site/*.jade', ['jade']);
   gulp.watch('site/css/*.sass', ['sass']);
   gulp.watch('site/*.html', browserSync.reload);
   gulp.watch('site/css/*.css', browserSync.reload);
   // Other watchers
});

gulp.task('default',['watch']);
